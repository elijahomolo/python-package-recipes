#!/bin/bash

pip install /Users/eomolo/projects/packages/scikit-spark/scikit_spark-0.1.0-py2-none-any.whl --no-deps
