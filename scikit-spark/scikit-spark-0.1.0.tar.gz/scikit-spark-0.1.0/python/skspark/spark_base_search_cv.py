import warnings
from collections import defaultdict
from functools import partial

import six
import numpy as np
from itertools import product
from sklearn.base import is_classifier, clone
from sklearn.externals.joblib import Parallel, delayed
from sklearn.metrics.scorer import _check_multimetric_scoring
from sklearn.model_selection import check_cv
from sklearn.model_selection._validation import _fit_and_score, \
    _aggregate_score_dicts
from sklearn.utils import indexable
from sklearn.model_selection._search import BaseSearchCV
from sklearn.utils.deprecation import DeprecationDict
from sklearn.utils.fixes import MaskedArray
from scipy.stats import rankdata
from pyspark.sql import SparkSession


class SparkBaseSearchCV(BaseSearchCV):
    def __init__(self, spark, estimator, scoring=None, fit_params=None,
                 n_jobs=1, iid=True, refit=True, cv=None, verbose=0,
                 pre_dispatch='2*n_jobs', error_score='raise',
                 return_train_score=True):

        super(SparkBaseSearchCV, self).__init__(
            estimator, scoring, fit_params, n_jobs, iid, refit, cv, verbose,
            pre_dispatch, error_score, return_train_score)

        if isinstance(spark, SparkSession):
            self.spark = spark
        elif spark:
            self.spark = SparkSession.builder.getOrCreate()
        else:
            self.spark = None

        # TODO: I'm not doing whatever pre_dispatch is supposed to do

    def fit(self, X, y=None, groups=None, **fit_params):
        """Run fit with all sets of parameters.

        Parameters
        ----------

        X : array-like, shape = [n_samples, n_features]
            Training vector, where n_samples is the number of samples and
            n_features is the number of features.

        y : array-like, shape = [n_samples] or [n_samples, n_output], optional
            Target relative to X for classification or regression;
            None for unsupervised learning.

        groups : array-like, with shape (n_samples,), optional
            Group labels for the samples used while splitting the dataset into
            train/test set.

        **fit_params : dict of string -> object
            Parameters passed to the ``fit`` method of the estimator
        """
        if self.fit_params is not None:
            warnings.warn('"fit_params" as a constructor argument was '
                          'deprecated in version 0.19 and will be removed '
                          'in version 0.21. Pass fit parameters to the '
                          '"fit" method instead.', DeprecationWarning)
            if fit_params:
                warnings.warn('Ignoring fit_params passed as a constructor '
                              'argument in favor of keyword arguments to '
                              'the "fit" method.', RuntimeWarning)
            else:
                fit_params = self.fit_params
        estimator = self.estimator
        cv = check_cv(self.cv, y, classifier=is_classifier(estimator))

        scorers, self.multimetric_ = _check_multimetric_scoring(
            self.estimator, scoring=self.scoring)

        if self.multimetric_:
            if self.refit is not False and (
                    not isinstance(self.refit, six.string_types) or
                    # This will work for both dict / list (tuple)
                    self.refit not in scorers):
                raise ValueError("For multi-metric scoring, the parameter "
                                 "refit must be set to a scorer key "
                                 "to refit an estimator with the best "
                                 "parameter setting on the whole data and "
                                 "make the best_* attributes "
                                 "available for that metric. If this is not "
                                 "needed, refit should be set to False "
                                 "explicitly. %r was passed." % self.refit)
            else:
                refit_metric = self.refit
        else:
            refit_metric = 'score'

        X, y, groups = indexable(X, y, groups)
        n_splits = cv.get_n_splits(X, y, groups)
        # Regenerate parameter iterable for each fit
        candidate_params = list(self._get_param_iterator())
        n_candidates = len(candidate_params)
        if self.verbose > 0:
            print("Fitting {0} folds for each of {1} candidates, totalling"
                  " {2} fits".format(n_splits, n_candidates,
                                     n_candidates * n_splits))

        base_estimator = clone(self.estimator)

        if self.spark is None:
            out = self._run_sklearn_fit(base_estimator, X, y, scorers,
                                        fit_params, candidate_params, cv,
                                        groups)
        else:
            out = self._run_skspark_fit(base_estimator, X, y, scorers,
                                        fit_params, candidate_params, cv,
                                        groups)

        # if one choose to see train score, "out" will contain train score info
        if self.return_train_score:
            (train_score_dicts, test_score_dicts, test_sample_counts, fit_time,
             score_time) = zip(*out)
        else:
            (test_score_dicts, test_sample_counts, fit_time,
             score_time) = zip(*out)

        # test_score_dicts and train_score dicts are lists of dictionaries and
        # we make them into dict of lists
        test_scores = _aggregate_score_dicts(test_score_dicts)
        if self.return_train_score:
            train_scores = _aggregate_score_dicts(train_score_dicts)

        # TODO: replace by a dict in 0.21
        results = (DeprecationDict() if self.return_train_score == 'warn'
                   else {})

        def _store(key_name, array, weights=None, splits=False, rank=False):
            """A small helper to store the scores/times to the cv_results_"""
            # When iterated first by splits, then by parameters
            # We want `array` to have `n_candidates` rows and `n_splits` cols.
            array = np.array(array, dtype=np.float64).reshape(n_candidates,
                                                              n_splits)
            if splits:
                for split_i in range(n_splits):
                    # Uses closure to alter the results
                    results["split%d_%s"
                            % (split_i, key_name)] = array[:, split_i]

            array_means = np.average(array, axis=1, weights=weights)
            results['mean_%s' % key_name] = array_means
            # Weighted std is not directly available in numpy
            array_stds = np.sqrt(np.average((array -
                                             array_means[:, np.newaxis]) ** 2,
                                            axis=1, weights=weights))
            results['std_%s' % key_name] = array_stds

            if rank:
                results["rank_%s" % key_name] = np.asarray(
                    rankdata(-array_means, method='min'), dtype=np.int32)

        _store('fit_time', fit_time)
        _store('score_time', score_time)
        # Use one MaskedArray and mask all the places where the param is not
        # applicable for that candidate. Use defaultdict as each candidate may
        # not contain all the params
        param_results = defaultdict(partial(MaskedArray,
                                            np.empty(n_candidates, ),
                                            mask=True,
                                            dtype=object))
        for cand_i, params in enumerate(candidate_params):
            for name, value in params.items():
                # An all masked empty array gets created for the key
                # `"param_%s" % name` at the first occurence of `name`.
                # Setting the value at an index also unmasks that index
                param_results["param_%s" % name][cand_i] = value

        results.update(param_results)
        # Store a list of param dicts at the key 'params'
        results['params'] = candidate_params

        # NOTE test_sample counts (weights) remain the same for all candidates
        test_sample_counts = np.array(test_sample_counts[:n_splits],
                                      dtype=np.int)
        for scorer_name in scorers.keys():
            # Computed the (weighted) mean and std for test scores alone
            _store('test_%s' % scorer_name, test_scores[scorer_name],
                   splits=True, rank=True,
                   weights=test_sample_counts if self.iid else None)
            if self.return_train_score:
                prev_keys = set(results.keys())
                _store('train_%s' % scorer_name, train_scores[scorer_name],
                       splits=True)

                if self.return_train_score == 'warn':
                    for key in set(results.keys()) - prev_keys:
                        message = (
                            'You are accessing a training score ({!r}), '
                            'which will not be available by default '
                            'any more in 0.21. If you need training scores, '
                            'please set return_train_score=True').format(key)
                        # warn on key access
                        results.add_warning(key, message, FutureWarning)

        # For multi-metric evaluation, store the best_index_, best_params_ and
        # best_score_ iff refit is one of the scorer names
        # In single metric evaluation, refit_metric is "score"
        if self.refit or not self.multimetric_:
            self.best_index_ = results["rank_test_%s" % refit_metric].argmin()
            self.best_params_ = candidate_params[self.best_index_]
            self.best_score_ = results["mean_test_%s" % refit_metric][
                self.best_index_]

        if self.refit:
            self.best_estimator_ = clone(base_estimator).set_params(
                **self.best_params_)
            if y is not None:
                self.best_estimator_.fit(X, y, **fit_params)
            else:
                self.best_estimator_.fit(X, **fit_params)

        # Store the only scorer not as a dict for single metric evaluation
        self.scorer_ = scorers if self.multimetric_ else scorers['score']

        self.cv_results_ = results
        self.n_splits_ = n_splits

        return self

    def _run_sklearn_fit(self, base_estimator, X, y, scorers, fit_params,
                         candidate_params, cv, groups):
        """Run fitting locally"""
        pre_dispatch = self.pre_dispatch

        out = Parallel(
            n_jobs=self.n_jobs, verbose=self.verbose,
            pre_dispatch=pre_dispatch
        )(delayed(_fit_and_score)(clone(base_estimator), X, y, scorers, train,
                                  test, self.verbose, parameters,
                                  fit_params=fit_params,
                                  return_train_score=self.return_train_score,
                                  return_n_test_samples=True,
                                  return_times=True, return_parameters=False,
                                  error_score=self.error_score)
          for parameters, (train, test) in product(candidate_params,
                                                   cv.split(X, y, groups)))

        return out

    def _run_skspark_fit(self, base_estimator, X, y, scorers, fit_params,
                         candidate_params, cv, groups):
        param_grid = [(parameters, train, test) for parameters, (train, test)
                      in product(candidate_params, cv.split(X, y, groups))]

        # Because the original python code expects a certain order for the
        # elements, we need to respect it.
        indexed_param_grid = list(zip(range(len(param_grid)), param_grid))
        par_param_grid = self.spark.sparkContext.parallelize(
            indexed_param_grid, len(indexed_param_grid))

        X_bc = self.spark.sparkContext.broadcast(X)
        y_bc = self.spark.sparkContext.broadcast(y)

        verbose = self.verbose
        error_score = self.error_score
        return_train_score = self.return_train_score

        def spark_task(tup):
            (index, (parameters, train, test)) = tup
            local_estimator = clone(base_estimator)
            local_X = X_bc.value
            local_y = y_bc.value

            error = None
            with warnings.catch_warnings(record=True) as warns:
                try:
                    res = _fit_and_score(
                        local_estimator, local_X, local_y, scorers, train, test,
                        verbose, parameters, fit_params,
                        return_train_score=return_train_score,
                        return_parameters=True,
                        return_n_test_samples=True, return_times=True,
                        error_score=error_score)
                except Exception as e:
                    res = None
                    error = e

            return index, {"results": res, "errors": error, "warnings": warns}

        indexed_out0 = dict(par_param_grid.map(spark_task).collect())

        # process errors and warnings
        for i in range(len(param_grid)):
            error_to_be_raised = indexed_out0[i]["errors"]
            if error_to_be_raised is not None:
                raise error_to_be_raised

            for warn in indexed_out0[i]["warnings"]:
                warnings.warn(warn.message, warn.category)

        out = [indexed_out0[i]["results"][:-1] for i in range(len(param_grid))]

        X_bc.unpersist()
        y_bc.unpersist()
        return out

    def __getstate__(self):
        """To not try to pickle the non-serializable SparkSession"""
        attributes = dict(self.__dict__)
        if 'spark' in attributes.keys():
            del attributes['spark']
        return attributes
